#!/bin/bash


git config user.name "lucgithub343"
git config user.email "luc.github@hotmail.com"
git config credential.username "lucgithub343"
