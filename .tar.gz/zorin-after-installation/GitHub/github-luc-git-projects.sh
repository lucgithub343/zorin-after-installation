#!/bin/bash


git config user.name "luc-git-projects"
git config user.email "luc.git.projects@hotmail.com"
git config credential.username "luc-git-projects"
